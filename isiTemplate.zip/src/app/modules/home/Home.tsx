import SimpleContainer from '../../base/components/Container/SimpleContainer'
import Breadcrumb from '../../base/components/Template/Breadcrumb/Breadcrumb'
import { H2 } from '../../base/components/Template/Typography'
import { homeRoutesMap } from './HomeRoutes'

/**
 * @description Dashboard inicial
 * @constructor
 */
const Home = () => {
  return (
    <SimpleContainer>
      <Breadcrumb routeSegments={[homeRoutesMap.home]} />
      <H2>Página Principal</H2>
    </SimpleContainer>
  )
}

export default Home
