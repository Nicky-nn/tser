En caso de realizar la instalación por primera vez, se copian los archivos comprimidos
a modules/base para tener la base del home y de restricción